import 'package:flutter/material.dart';

class AppLogo extends StatelessWidget {
  final double size;

  const AppLogo({
    super.key,
    this.size = 120,
  });

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'lib/assets/images/logo.jpg',
      width: size,
      height: size,
      fit: BoxFit.contain,
    );
  }
}